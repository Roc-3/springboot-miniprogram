export const config = {
  baseFileUrl: "http://localhost:8888/files/download/"
}